<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class contact_message extends Model
{
    //
}
